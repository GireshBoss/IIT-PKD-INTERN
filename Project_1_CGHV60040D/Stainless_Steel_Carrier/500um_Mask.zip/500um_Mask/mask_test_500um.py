# -*- coding: utf-8 -*-
"""
Created on Thur June 2025

@author: giresh
"""

import numpy as np


from phidl import Device, Layer, LayerSet, make_device
from phidl import quickplot as qp # Rename "quickplot()" to the easier "qp()"
import phidl.geometry as pg
import phidl.routing as pr
import phidl.utilities as pu
from phidl.utilities import write_svg

from phidl import quickplot as qp 
from phidl import quickplot as qp # Rename "quickplot()" to the easier "qp()"
import phidl.geometry as pg

#phidl.set_quickplot_options(new_window=1)


def my_write_svg(D, filename, scale = 0.001):
    xsize, ysize = D.size
    dcx, dcy = D.center
    dx, dy = dcx-xsize/2, dcy-ysize/2
    group_num = 1
    if filename[-4:] != '.svg':  filename += '.svg'
    with open(filename, 'w+') as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n')
        f.write(('<svg\n'
                '   xmlns:svg="http://www.w3.org/2000/svg"\n'
                '   xmlns="http://www.w3.org/2000/svg"\n'                
                '   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"\n'
                '   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"\n'
                '   viewBox="%0.6f %0.6f %0.6f %0.6f" \n   width="%0.6fmm" \n   height="%0.6fmm"\n' 
                '   version="1.1">\n\n')
                % (0,0, xsize*scale, ysize*scale, xsize*scale, ysize*scale))

        f.write('<sodipodi:namedview \n'
                 'inkscape:document-units="mm" /> \n\n' )
 
        all_polygons = D.get_polygons(by_spec = True)
        for layer, polygons in all_polygons.items():
            color = '#800000'
            #color = _get_layerprop(layer = layer[0] , datatype = layer[1])['color']
            f.write('<g id="layer%03i_datatype%03i"\n' 
                    'inkscape:groupmode="layer"\n'
                    'inkscape:label="F.Cu">\n\n'
                    % (layer[0], layer[1]))
            group_num += 1

            for polygon in polygons:
                poly_str = '<path style="fill:%s"\n          d="' % color
                n = 0
                for p in polygon:
                    if n == 0: poly_str+= 'M '
                    else:      poly_str+= 'L '
                    poly_str += '%0.6f %0.6f '  % ((p[0]-dx)*scale,(-(p[1]-dy)+ysize)*scale)
                    n += 1
                poly_str+= 'Z"/>\n'
                f.write(poly_str)
            f.write('  </g>\n')

        f.write('</svg>\n')
    return filename

###########################################################################################




D = Device('mydevice1')
D << Device('mydevice1')





D = pg.basic_die(
              size = (50000, 50000), # Size of die
              street_width = 0,   # Width of corner marks for die-sawing
              street_length = 0, # Length of corner marks for die-sawing
              die_name = '',  # Label text
              text_size = 0,      # Label text size
              text_location = 'NW', # Label text compass location e.g. 'S', 'SE', 'SW'
              layer = 0,
              draw_bbox = False,
              bbox_layer = 99,
              )



# dimensions in microns

#l_c = 4000  # length of the center rectangle - mask 1
#b_c = 700   # width of the center rectangle - mask 1
#l = 4000    # length of the rectangle - mask 1
#b = 700     # width of the rectangle - mask 1
#l_2 = 1700  # length of the rectangle - mask 2
#b_2 = 1700  # width of the rectangle - mask 2
#m = 200     # width of the marker
#l_al = 500  # length of the top contact - mask 3
#b_al = 2000 # width of the top contact - mask 3



#x=0
#y=0
#
#
#
xpts = (-250,250,250,-250,-250)
ypts = (-250,-250,250,250,-250)

poly = D.add_polygon( [xpts, ypts], layer = 0)

#
#x3 = 2500    # centre position of the marker 3
#y3 = -2500
#
#xpts3 = (x+x3+(m/2), x+x3+(m/2), x+x3-(m/2), x+x3-(m/2), x+x3-(m/2), x+x3-(3*m/2), x+x3-(3*m/2), x+x3+(3*m/2), x+x3+(3*m/2), x+x3-(m/2), x+x3-(m/2))
#ypts3 = (y+y3+(m/2), y+y3-(m/2), y+y3-(m/2), y+y3+(m/2), y+y3+(3*m/2), y+y3+(3*m/2), y+y3-(3*m/2), y+y3-(3*m/2), y+y3+(3*m/2), y+y3+(3*m/2), y+y3+(m/2))
#
#poly3 = D.add_polygon( [xpts3, ypts3], layer = 0)
#
#
#x4 = -2500   # centre position of the marker 4
#y4 = -2500
#
#xpts4 = (x+x4+(m/2), x+x4+(m/2), x+x4-(m/2), x+x4-(m/2), x+x4-(m/2), x+x4-(3*m/2), x+x4-(3*m/2), x+x4+(3*m/2), x+x4+(3*m/2), x+x4-(m/2), x+x4-(m/2))
#ypts4 = (y+y4+(m/2), y+y4-(m/2), y+y4-(m/2), y+y4+(m/2), y+y4+(3*m/2), y+y4+(3*m/2), y+y4-(3*m/2), y+y4-(3*m/2), y+y4+(3*m/2), y+y4+(3*m/2), y+y4+(m/2))
#
#poly4 = D.add_polygon( [xpts4, ypts4], layer = 0)
#
#
#x5 = -2500   # centre position of the marker 1
#y5 = 2500
#
#xpts5 = (x+x5+(m/2), x+x5+(m/2), x+x5-(m/2), x+x5-(m/2), x+x5-(m/2), x+x5-(3*m/2), x+x5-(3*m/2), x+x5+(3*m/2), x+x5+(3*m/2), x+x5-(m/2), x+x5-(m/2))
#ypts5 = (y+y5+(m/2), y+y5-(m/2), y+y5-(m/2), y+y5+(m/2), y+y5+(3*m/2), y+y5+(3*m/2), y+y5-(3*m/2), y+y5-(3*m/2), y+y5+(3*m/2), y+y5+(3*m/2), y+y5+(m/2))
#
#poly5 = D.add_polygon( [xpts5, ypts5], layer = 0)
#
#
#x6 = 2500    # centre position of the marker 2
#y6 = 2500
#
#xpts6 = (x+x6+(m/2), x+x6+(m/2), x+x6-(m/2), x+x6-(m/2), x+x6-(m/2), x+x6-(3*m/2), x+x6-(3*m/2), x+x6+(3*m/2), x+x6+(3*m/2), x+x6-(m/2), x+x6-(m/2))
#ypts6 = (y+y6+(m/2), y+y6-(m/2), y+y6-(m/2), y+y6+(m/2), y+y6+(3*m/2), y+y6+(3*m/2), y+y6-(3*m/2), y+y6-(3*m/2), y+y6+(3*m/2), y+y6+(3*m/2), y+y6+(m/2))
#
#poly6 = D.add_polygon( [xpts6, ypts6], layer = 0)



E = pg.invert(D, border = 0, precision = 1e-6, layer = 0)
#E.write_gds('MASK_rekha.gds')

A = Device()
#d_ref1 = A.add_array(E, columns = 8, rows = 8, spacing = [9000,9000]) # making array of masks
d_ref1 = A.add_array(E, columns = 1, rows = 1) #single mask


A.write_gds('MASK_test_500um.gds')
my_write_svg(A, filename = 'MASK_test_500um.svg')
qp(A) # quickplot it!


